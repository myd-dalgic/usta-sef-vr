# UstaŞef VR 🍕🍔

Kompakt bir VR restoran/fast-food simülasyonu. Meta Quest 3 için WebXR + Three.js ile geliştiriliyor.

## Konsept
- Küçük harita: dışarıda müşteri bekleme alanı, ortada orta boy dükkan
- Sabit menü: pizza, hamburger, patates kızartması, içecek
- Sınırsız/sürekli müşteri akışı
- Yangın tüpü ile söndürme, çekiç/levye ile makine tamiri
- Eldiven eller (aşçı temalı kontrolcü görselleri)

## Mutfak İstasyonları (v0.1)
- Izgara
- Fritöz
- Fırın (Pizza)
- İçecek Makinesi
- Hazırlık Tezgahı
- Yangın Tüpü
- Tamir Çekici İstasyonu

## Çalıştırma
Basit bir statik sunucuyla açılabilir (WebXR için HTTPS veya localhost gerekir):

```bash
npx serve .
```

Ardından Meta Quest 3 tarayıcısından adrese girip "VR'a Gir" butonuna basın.

## Yol Haritası
- [ ] Müşteri spawn ve sipariş sistemi
- [ ] El etkileşimleri (doğrama, tutma, tabaklama)
- [ ] Yemek pişirme mekanikleri (ızgara, fritöz, fırın)
- [ ] Yanma/duman/yangın sistemi
- [ ] Makine arıza + tamir mekaniği
- [ ] Skor / bahşiş sistemi
- [ ] Ses efektleri ve müzik

## Deploy
GitHub Pages üzerinden yayınlanacak.
