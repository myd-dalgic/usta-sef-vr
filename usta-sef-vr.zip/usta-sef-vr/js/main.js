import * as THREE from 'three';
import { VRButton } from 'three/addons/webxr/VRButton.js';
import { XRControllerModelFactory } from 'three/addons/webxr/XRControllerModelFactory.js';

// ---------- TEMEL SAHNE ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb); // açık gökyüzü mavisi (dışarısı)

const camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.05, 100);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(window.devicePixelRatio);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.xr.enabled = true;
renderer.shadowMap.enabled = true;
document.body.appendChild(renderer.domElement);

// ---------- IŞIKLANDIRMA ----------
const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 1.2);
scene.add(hemiLight);

const sunLight = new THREE.DirectionalLight(0xffffff, 1.5);
sunLight.position.set(5, 10, 5);
sunLight.castShadow = true;
sunLight.shadow.mapSize.set(2048, 2048);
scene.add(sunLight);

// ---------- OYUNCU RIG (dolly) ----------
// playerRig: hareket/teleport için taşınacak grup. Kamera ve kontrolcüler buna bağlı.
const playerRig = new THREE.Group();
playerRig.position.set(0, 0, 3); // dükkanın önünde, dışarıda başlasın
scene.add(playerRig);
playerRig.add(camera);

// ---------- KONTROLCÜLER (eldiven eller) ----------
const controllerModelFactory = new XRControllerModelFactory();

function createGloveHand(color) {
  // Basit eldiven-eli temsil eden geçici mesh (ileride detaylı model ile değiştirilecek)
  const group = new THREE.Group();
  const palm = new THREE.Mesh(
    new THREE.BoxGeometry(0.08, 0.03, 0.11),
    new THREE.MeshStandardMaterial({ color })
  );
  palm.position.z = -0.05;
  group.add(palm);
  return group;
}

const controller1 = renderer.xr.getController(0);
const controller2 = renderer.xr.getController(1);
controller1.add(createGloveHand(0xffffff)); // sol eldiven - beyaz aşçı eldiveni
controller2.add(createGloveHand(0xffffff)); // sağ eldiven
playerRig.add(controller1);
playerRig.add(controller2);

const grip1 = renderer.xr.getControllerGrip(0);
grip1.add(controllerModelFactory.createControllerModel(grip1));
playerRig.add(grip1);

const grip2 = renderer.xr.getControllerGrip(1);
grip2.add(controllerModelFactory.createControllerModel(grip2));
playerRig.add(grip2);

// ---------- ZEMİN: DIŞARISI (müşteri alanı) ----------
const outsideFloor = new THREE.Mesh(
  new THREE.PlaneGeometry(10, 8),
  new THREE.MeshStandardMaterial({ color: 0x999999 })
);
outsideFloor.rotation.x = -Math.PI / 2;
outsideFloor.position.set(0, 0, 4);
outsideFloor.receiveShadow = true;
scene.add(outsideFloor);

// Müşteri sırası bekleme alanı işaretleri (geçici - sarı çizgiler)
for (let i = 0; i < 3; i++) {
  const marker = new THREE.Mesh(
    new THREE.RingGeometry(0.3, 0.35, 16),
    new THREE.MeshBasicMaterial({ color: 0xffcc00, side: THREE.DoubleSide })
  );
  marker.rotation.x = -Math.PI / 2;
  marker.position.set(0, 0.01, 5 + i * 1.2);
  scene.add(marker);
}

// ---------- DÜKKAN (orta boy kapalı alan) ----------
const shopGroup = new THREE.Group();
scene.add(shopGroup);

const shopFloor = new THREE.Mesh(
  new THREE.PlaneGeometry(8, 6),
  new THREE.MeshStandardMaterial({ color: 0xdeb887 })
);
shopFloor.rotation.x = -Math.PI / 2;
shopFloor.position.set(0, 0, -2);
shopFloor.receiveShadow = true;
shopGroup.add(shopFloor);

// Dükkan duvarları (basit kutu duvarlar, önü açık - müşteri tarafı)
const wallMat = new THREE.MeshStandardMaterial({ color: 0xf5deb3 });
function makeWall(w, h, d, x, y, z) {
  const wall = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), wallMat);
  wall.position.set(x, y, z);
  wall.castShadow = true;
  wall.receiveShadow = true;
  shopGroup.add(wall);
  return wall;
}
makeWall(8, 3, 0.2, 0, 1.5, -5);   // arka duvar
makeWall(0.2, 3, 6, -4, 1.5, -2);  // sol duvar
makeWall(0.2, 3, 6, 4, 1.5, -2);   // sağ duvar

// ---------- MUTFAK İSTASYONLARI (yer tutucu kutular - iteratif geliştirilecek) ----------
const stations = [];

function createStation(name, color, x, z, size = [0.8, 0.9, 0.6]) {
  const geo = new THREE.BoxGeometry(...size);
  const mat = new THREE.MeshStandardMaterial({ color });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.position.set(x, size[1] / 2, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mesh.userData.stationName = name;
  shopGroup.add(mesh);
  stations.push(mesh);
  return mesh;
}

createStation('Izgara', 0x8b3a3a, -3, -4);
createStation('Fritöz', 0xd2691e, -1.5, -4);
createStation('Fırın (Pizza)', 0x5a3825, 0, -4);
createStation('İçecek Makinesi', 0x3a6ea5, 1.5, -4);
createStation('Hazırlık Tezgahı', 0x777777, 3, -4, [1.2, 0.9, 0.6]);
createStation('Yangın Tüpü', 0xcc0000, -3.6, -1, [0.25, 0.6, 0.25]);
createStation('Tamir Çekici İstasyonu', 0x444444, 3.6, -1, [0.4, 0.6, 0.3]);

// ---------- RESIZE ----------
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

// ---------- VR GİRİŞ (double-fallback pattern) ----------
document.getElementById('vr-button-container').appendChild(
  VRButton.createButton(renderer, { optionalFeatures: ['local-floor', 'bounded-floor'] })
);

// ---------- RENDER LOOP ----------
renderer.setAnimationLoop(() => {
  renderer.render(scene, camera);
});
